﻿using Dapper;
using Repository.Data.ConfiguracionesDB;
using System.Data;

namespace Repository.Data.Personas
{
    public class PersonaRepository : IPersonaRepository
    {
        IDbConnection connection;

        public PersonaRepository(string connectionString)
        {
            connection = new ConnectionDB(connectionString).OpenConnection();
        }

        public class ServicioSucursal
        {
            private string _direccion;
            private string _email;

            public string Direccion
            {
                get { return _direccion; }
                set
                {
                    if (value.Length >= 10)
                    {
                        _direccion = value;
                    }
                    else
                    {
                        throw new ArgumentException("La dirección debe tener al menos 10 caracteres de longitud.");
                    }
                }
            }

            public string Email
            {
                get { return _email; }
                set
                {
                    if (ValidarEmail(value))
                    {
                        _email = value;
                    }
                    else
                    {
                        throw new ArgumentException("El formato del correo electrónico no es válido.");
                    }
                }
            }

            public ServicioSucursal(string direccion, string email)
            {
                Direccion = direccion;
                Email = email;
            }

            private bool ValidarEmail(string email)
            {
                // Verificar si el email contiene el @ y al menos un punto después del @
                return email.Contains("@") && email.Split('@')[1].Contains(".");
            }
        
        }
}
