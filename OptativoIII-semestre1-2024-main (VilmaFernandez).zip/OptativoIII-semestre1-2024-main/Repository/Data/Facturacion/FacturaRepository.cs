﻿using Dapper;
using Repository.Data.ConfiguracionesDB;
using System.Data;

namespace Repository.Data.Facturacion
{
    public class FacturaRepository : IFacturaRepository
    {
        IDbConnection connection;

        public FacturaRepository(string connectionString)
        {
            connection = new ConnectionDB(connectionString).OpenConnection();
        }

        public class ServicioFactura
        {
            private string _numeroFactura;
            private decimal _total;
            private decimal _totalIva5;
            private decimal _totalIva10;
            private decimal _totalIva;

            public string NumeroFactura
            {
                get { return _numeroFactura; }
                set
                {
                    if (ValidarNumeroFactura(value))
                    {
                        _numeroFactura = value;
                    }
                    else
                    {
                        throw new ArgumentException("El número de factura no cumple con el formato especificado.");
                    }
                }
            }

            public decimal Total
            {
                get { return _total; }
                set { _total = value; }
            }

            public decimal TotalIva5
            {
                get { return _totalIva5; }
                set { _totalIva5 = value; }
            }

            public decimal TotalIva10
            {
                get { return _totalIva10; }
                set { _totalIva10 = value; }
            }

            public decimal TotalIva
            {
                get { return _totalIva; }
                set { _totalIva = value; }
            }

            public ServicioFactura(string numeroFactura, decimal total, decimal totalIva5, decimal totalIva10, decimal totalIva)
            {
                NumeroFactura = numeroFactura;
                Total = total;
                TotalIva5 = totalIva5;
                TotalIva10 = totalIva10;
                TotalIva = totalIva;
            }

            private bool ValidarNumeroFactura(string numeroFactura)
            {
                // Patrón para validar el número de factura
                string patron = @"^\d{3}-\d{3}-\d{6}$";
                return Regex.IsMatch(numeroFactura, patron);
            }

            public string TotalEnLetras()
            {
                // Implementa lógica para convertir el total en letras
                // Esta es una implementación simplificada, puedes usar bibliotecas externas para esta conversión
                // o implementar un algoritmo personalizado.
                return "";
            }

        }
}
